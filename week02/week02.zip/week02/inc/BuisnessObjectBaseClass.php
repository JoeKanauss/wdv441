<?php

class BusinessObjectBase
{
	function load($recordToLoad)
	{
		
	}
	
	function validate($dataArray)
	{
		
	}
	
	function save($dataArray)
	{
		
	}
}


?>